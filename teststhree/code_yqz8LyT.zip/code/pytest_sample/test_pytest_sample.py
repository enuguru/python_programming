# pytest_sample/test_pytest_sample.py

def test_always_pass():
    assert True

def test_always_fail():
    assert False
