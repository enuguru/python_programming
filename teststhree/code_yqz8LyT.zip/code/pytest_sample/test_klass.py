# pytest_sample/test_klass.py

class SampleClass:
    def test_always_pass(self):
        assert True

    def test_always_fail(self):
        assert False
