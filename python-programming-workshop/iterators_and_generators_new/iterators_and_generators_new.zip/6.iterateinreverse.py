
a = [1, 2, 3, 4]
for x in reversed(a):
    print(x)
