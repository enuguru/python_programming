
for i in [1,2,2,5]:
    print(i)
