def remove_duplicates(numbers):
    return set(numbers)

print(remove_duplicates([1,2,3,4,4,3,4,4,4,1,4,4,4,3,4,5,3]))

