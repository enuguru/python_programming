def is_palindrome(string):
    string = string.lower()
    is_palindrome = True
    for i,c in enumerate(string):
        if string[i] != string[-(i+1)]:
            is_palindrome = False
            break
    print(is_palindrome)


is_palindrome("MADAm")
