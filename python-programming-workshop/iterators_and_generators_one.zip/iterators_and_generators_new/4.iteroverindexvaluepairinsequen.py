
#The built-in enumerate() function handles this quite nicely

my_list = ['a', 'b', 'c']
for idx, val in enumerate(my_list):
    print(idx, val)
