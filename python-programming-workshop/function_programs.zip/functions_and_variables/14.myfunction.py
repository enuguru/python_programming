

def myfunction():
	print("We are inside myfunction()")

myfunction()
