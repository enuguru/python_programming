


def myfunction():
	print("We are inside myfunction()")
	yourfunction()


def yourfunction():
	print("We are inside yourfunction()")


myfunction()




