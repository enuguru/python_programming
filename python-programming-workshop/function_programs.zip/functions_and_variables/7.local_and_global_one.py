

def yourfunction(): 
    print(mystr) 

mystr = "Hello How are you doing"
yourfunction()
