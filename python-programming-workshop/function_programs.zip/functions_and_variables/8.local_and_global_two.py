
def yourfunction(): 
    mystr = "I am fine"
    print(mystr) 

mystr = "Hello How are you doing?" 
print(yourfunction())
print(mystr)
