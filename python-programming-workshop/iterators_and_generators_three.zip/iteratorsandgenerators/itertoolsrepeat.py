
import itertools

# Repeat the value 5 four times.
result = itertools.repeat(5, 4)
print(list(result))
