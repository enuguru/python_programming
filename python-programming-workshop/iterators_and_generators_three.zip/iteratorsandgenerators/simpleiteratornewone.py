
elements = ["cat", "dog", "horse", None, "gerbil"]

# Iter returns each element, one after another.
i = iter(elements)

print(next(i))
print(next(i))
print(next(i))
