
elements = ["cat", "dog", "horse", None, "gerbil"]

# Iter returns each element, one after another.
for element in iter(elements):
    print(element)
