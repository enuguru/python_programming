
print("Halt!")
mystr = input("Who goes there?")
print("You may pass,",  mystr)
