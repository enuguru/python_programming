
i = 90
print(i)

f = 90.567
print(f)


mystr = 'Jitender'
print(mystr)

p = 's'
print(p)
