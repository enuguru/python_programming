
# This program calculates speed with time and distance as inputs
print("Input a time and a distance")
time = float(input("time: "))
distance = float(input("Distance: "))
print("speed:", (distance / time))
