
print('Hello {name}, {greeting}'.format(greeting = 'Good morning', name = 'John'))
