
x = 12.3456789
print('The value of x is %1.2f' %x)
print('The value of x is %7.5f' %x)
