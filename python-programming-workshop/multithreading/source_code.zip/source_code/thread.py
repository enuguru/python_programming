import time

def myfunc():
    print('hello')
    time.sleep(10)
    return True

if __name__ == '__main__':
    myfunc()