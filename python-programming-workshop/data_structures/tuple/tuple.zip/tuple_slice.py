

values = (1, 3, 5, 7, 9, 11, 13)

print(values[0:6:2])
# Copy the tuple.
print(values[:])

# Copy all values at index 1 or more.
print(values[1:])

# Copy one value, starting at first.
print(values[:1])

# Copy values from index 2 to 4.
print(values[2:4])
