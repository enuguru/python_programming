

checks = (10, 20, 30)

# Add two tuples.
more = checks + checks
print(more)

# Multiply tuple.
total = checks * 3
print(total)
