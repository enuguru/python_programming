
# once you create a tuple it cannot be changed.  tuple is immutable


tuple = ('cat', 'dog', 'mouse')

# This causes an error.
tuple[0] = 'feline'
