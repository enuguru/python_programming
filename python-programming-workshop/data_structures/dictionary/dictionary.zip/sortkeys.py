
# Same as previous program.
hits = {"home": 124, "sitemap": 26, "about": 32}

# Sort the keys from the dictionary.
keys = sorted(hits.keys())

print(keys)
values = sorted(hits.values())
print(values)
