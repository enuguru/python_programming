
mydic = { "4" : 24, "5" : 34 }
for key in mydic.items() :
    print (key)
