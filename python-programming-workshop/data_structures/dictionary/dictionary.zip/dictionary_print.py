
lookup = {"cat": 1, "dog": 2}

#The dictionary has no fish key!
print(lookup["cat"])
print(lookup)
