
columns = 4
rows = 3
a = [[x+2 for x in range(columns)] for y in range(rows)]
print(a)

x = [[i+3 for i in range(1,10)] for j in range(1,10)]
print(x)
