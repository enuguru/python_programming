
from math import pi
pivalues = [round(pi, i) for i in range(1, 6)]
print(pivalues)
