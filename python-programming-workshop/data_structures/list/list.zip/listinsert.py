
#you can use either single quotes or double quotes

list = ['dot', 'perls']

# Insert at index 1.
list.insert(1, "net")
list.insert(2,"Mounika")
print(list.pop())

print(list)
