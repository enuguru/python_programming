
# Two lists.
a = [1, 2, 3]
b = [4, 5, 6]

# Add all elements in list "b" to list "a."
a.extend(b)

# List "a" now contains six elements.
print(a)
