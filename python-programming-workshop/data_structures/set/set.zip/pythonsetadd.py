
# An empty set.
items = set()

# Add three strings.
items.add("cat")
items.add("dog")
items.add("gerbil")
items.add("gerbil")
items.add("cow")
animal = input("give an domestic animal name")
items.add(animal)
print(items)
