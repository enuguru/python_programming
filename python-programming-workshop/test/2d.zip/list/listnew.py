
#int i = 56;
#i = 56

#dynamic typing or duck typing

#if it swims and quacks like a duck it is duck

mylist = [45.56, 34, "Manesh", 'c']
mylist.append("Guru")
mylist.insert(2,45)
print(mylist)
print(mylist[2])

mylist = [[34,45,'b'],45,"guru",["Manesh",45] ]
print(mylist[3])

mylist = [ [34,2,3],[45,78,5] ]
print(mylist[1][0])
