
from array import array

a = array('l')
b=array('u', 'hello \u2641')
c=array('l', [1, 2, 3, 4, 5])
d=array('d', [1.0, 2.0, 3.14])
