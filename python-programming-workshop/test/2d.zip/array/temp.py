
import array

# New int array.
a = array.array("i")

# Append three integers.
a.append(100)
a.append(200)
a.append(300)

# Print.
print(a)
