

# Create an empty list.
a = list()

# Append ints.
for i in range(0, 100):
    a.append(i)

# Finished.
print("DONE")
input()
