
from array import array

# Create an int array of three elements.
a = array("i", [10, 20, 30])

# Display elements in array.
for value in a:
    print(value)
