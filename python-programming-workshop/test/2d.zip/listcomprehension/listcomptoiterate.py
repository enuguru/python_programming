
result = [x + y for x in 'ball' for y in 'boy']
print(result)
