
x = [i for i in range(10)]
print(x)
