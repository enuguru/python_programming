

result = list(map(ord,'Dostoyevsky'))
print(result)
