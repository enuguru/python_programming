
print(list(map((lambda x: x ** 2),range(7))))
