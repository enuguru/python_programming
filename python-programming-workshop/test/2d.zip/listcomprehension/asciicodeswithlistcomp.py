
result = [ord(x) for x in 'Dostoyevsky']
print(result)
