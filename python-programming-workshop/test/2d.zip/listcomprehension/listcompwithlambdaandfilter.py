
print(list(map((lambda x: x ** 2), filter((lambda x: x % 2== 0),range(10)))))
