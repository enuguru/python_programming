
print(ord('A'))
