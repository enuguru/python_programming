

result = []
for x in 'Dostoyevsky':
    result.append(ord(x))
print(result)
