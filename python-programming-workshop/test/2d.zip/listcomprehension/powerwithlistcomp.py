
result = [x ** 3 for x in range(5)]
print(result)
