
result = list(filter((lambda x: x % 2 == 0), range(10)))
print(result)
