
f = open('words.txt')
for x in f.read().split():
    print(x)
