

# Negative number.
n = -100.5

# Absolute value.
print(abs(n))

# Positive numbers are not changed.
print(abs(100.5))

# Zero is left alone.
print(abs(0))
