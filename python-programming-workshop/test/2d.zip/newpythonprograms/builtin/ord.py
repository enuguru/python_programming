

letters = "ABCabc123"

for letter in letters:
    # Get number that represents letter in ASCII.
    number = ord(letter)
    print(letter, "=", number)
