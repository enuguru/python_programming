

numbers = [97, 98, 99]

for number in numbers:
    # Convert ASCII-based number to character.
    letter = chr(number)
    print(number, "=", letter)
