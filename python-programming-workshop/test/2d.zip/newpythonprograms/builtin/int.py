

# Convert a string to int.
input = "123"
result = int(input)
print(result)

# Use int to convert from floating to integral.
input = 456.9
result = int(input)
print(result)

