

# Float converts a string into a float number.
value = "3.14"
number = float(value)
print(number)
print(number == 3.14)
print(value == "3.14")
print()

# Float also converts an integer into a float number.
integer = 100
floating = float(integer)
print(floating)
print(integer)
