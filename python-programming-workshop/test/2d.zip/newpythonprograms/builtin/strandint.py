

# Convert number to string.
number = 123
value = str(number)

# Print the string and its character count.
print(value)
print(len(value))

# Convert string to number.
number2 = int(value)

# Print the number and add one.
print(number2)
print(number2 + 1)
