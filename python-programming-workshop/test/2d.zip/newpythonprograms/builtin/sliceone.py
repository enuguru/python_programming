
values = [100, 200, 300, 400, 500]
# Get elements from second index to third index.
#slice = values[1:3]
slice = values[4::-2]
print(slice)
