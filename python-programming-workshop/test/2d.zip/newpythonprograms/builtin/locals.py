

def method():
    value1 = "bird"
    value2 = "fish"
    value3 = 400

    # Display locals dictionary.
    print(locals())

# Call the method.
method()

