

number = 100

# Convert this number to a binary string.
result = bin(number)
print(result)
