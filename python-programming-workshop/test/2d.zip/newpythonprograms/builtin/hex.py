

#Hex converts an integer into a hexadecimal number. This form of number can be useful in 
#interoperating with other programs and systems. We see the hex representations of 10 and 100.

# Convert this value to a hex.
value = 10
result = hex(value)
print(result)

# Convert another value.
value = 100
result = hex(value)
print(result)

