print("I'm spam")

def hello(name):
    print('Hello %s' % name)
