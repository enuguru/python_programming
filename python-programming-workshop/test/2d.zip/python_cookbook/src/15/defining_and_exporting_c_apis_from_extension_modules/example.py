import sample
import ptexample
p1 = sample.Point(2,3)
ptexample.print_point(p1)
