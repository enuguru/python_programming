import sample
print(sample.gcd(35,42))
print(sample.in_mandel(0,0,500))
print(sample.in_mandel(2.0,1.0,500))
print(sample.divide(42,8))
print(sample.avg([1,2,3]))
p1 = sample.Point(1,2)
p2 = sample.Point(4,5)
print(sample.distance(p1,p2))
