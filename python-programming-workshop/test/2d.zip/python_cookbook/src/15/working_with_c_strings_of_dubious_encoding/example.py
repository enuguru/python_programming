import sample
s = sample.retstr()
print(repr(s))
sample.print_chars(s)
