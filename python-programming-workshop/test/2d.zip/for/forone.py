
# Measure some strings:
words = ['cat', 'window', 'defenestrate']
for w in words:
    print(w, len(w))


family = ['karthik','Jayashree','BadriNarayanan','Gururajan']

for pen in family:
    print(pen, len(pen))
