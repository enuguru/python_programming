
while 0:
   print("Help, I'm stuck in a loop.")
