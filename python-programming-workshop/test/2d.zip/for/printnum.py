
for i in [1,4,5,7,9]:
    print(i)
