
# Three-item tuple.
items = ("cat", "dog", "bird")

# Get index of element with value "dog".
index = items.index("dog")
print(index, items[index])
items[1] = "zebra"
