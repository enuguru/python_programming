
# Python program that assigns tuple

tuple = ('cat', 'dog', 'mouse')

# This causes an error.
tuple[0] = 'feline'
