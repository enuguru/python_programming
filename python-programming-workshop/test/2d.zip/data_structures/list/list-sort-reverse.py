

list = [400, 500, 100, 2000]

print(list)
# Reversed.
list.reverse()
print(list)

# Sorted.
list.sort()
print(list)

# Sorted and reversed.
list.reverse()
print(list)
