
mylist = [1, 4, -5, 10, -7, 2, 3, -1]
import math
p=[math.sqrt(n) for n in mylist if n > 0]
print(p)
