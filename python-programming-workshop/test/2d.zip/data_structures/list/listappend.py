


list = []
list.append(1)
list.append(2)
list.append(6)
list.append(3)

print(list)
