
systems = {"mac": 1, "windows": 5, "linux": 1}

print(systems)

print(systems)

# Remove key-value at "windows" key.
del systems["windows"]

# Display dictionary.
print(systems)
