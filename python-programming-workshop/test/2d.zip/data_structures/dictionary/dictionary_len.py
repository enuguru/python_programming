

animals = {"parrot": 2, "fish": 6}

# Use len built-in on animals.
print("Length:", len(animals))
