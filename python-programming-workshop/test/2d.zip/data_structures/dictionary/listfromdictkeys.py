
for key in newdict.keys():
  print(key)
