


# Create a set from this list.
# ... Duplicates are ignored.
numbers = set([10, 20, 20, 30, 40, 50])
print(numbers)
