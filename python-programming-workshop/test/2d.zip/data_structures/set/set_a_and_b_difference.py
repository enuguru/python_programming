
a = {"new york", "connecticut", "new jersey",5}
b = {"connecticut", "pennsylvania", "maine"}

# Subtract.
c = a - b
print(c)

# Difference.
c = a.difference(b)
print(c)

# Subtract in opposite order.
c = b - a
print(c)

# Difference in opposite order.
c = b.difference(a)
print(c)
