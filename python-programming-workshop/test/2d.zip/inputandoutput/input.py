
print("Halt!")
user_input = input("Who goes there?")
print("You may pass,",  user_input)

