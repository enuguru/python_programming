
print('Hello {name}, {greeting}'.format(greeting = 'Goodmorning', name = 'John'))
