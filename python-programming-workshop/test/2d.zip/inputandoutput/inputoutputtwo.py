
num = float(input('Enter a number: '))
num = num + 20
print(num)
