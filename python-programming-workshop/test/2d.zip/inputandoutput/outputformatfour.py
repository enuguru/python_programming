
x = 12.3456789
print('The value of x is %3.2f' %x)
print('The value of x is %3.4f' %x)
