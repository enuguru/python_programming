print('This sentence is output to the screen')

