
test = input("----->> enter the test ")
print(test)
