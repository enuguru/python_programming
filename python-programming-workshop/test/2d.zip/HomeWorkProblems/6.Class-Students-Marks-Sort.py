
# After writing the above program, print the name of
# the student who is the class topper and who is the topper in each subject

students = {"Ravi":[["physics",47],["Mathematics",45],["Chemistry",45],["Biology",75]],\

             "Sneha":[["physics",95],["Mathematics",34],["Chemistry",45],["Biology",55]],\

"Priya":[["physics",45],["Mathematics",45],["Chemistry",41],["Biology",65]],\

"Kumar":[["physics",45],["Mathematics",83],["Chemistry",72],["Biology",35]],\

"Girish":[["physics",85],["Mathematics",41],["Chemistry",91],["Biology",45]], }

print(students)
