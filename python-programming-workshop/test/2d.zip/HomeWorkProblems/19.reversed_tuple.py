
## python program to reverse the given tuple ##

x = (1, 2, 3, 4)
print(" The given tuple : ",x)

y = reversed(x)
print(" The reversed tuple :",tuple(y))
