
# write a python program to add members to a set

newset = {23,34,2,1,5,7,91}

sum = 0

for number in newset:
    sum = sum + number
print(sum)