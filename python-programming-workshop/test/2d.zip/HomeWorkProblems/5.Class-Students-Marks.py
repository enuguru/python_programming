
# There are 5 students in a class, Ravi, Sneha, Priya, Kumar and Girish.
# There are studying in 10th standard. All of them study 6 subjects.
# Take input of all their marks in 6 subjects. Write a program to store
# their names and the corresponsing marks. print the names and the
# appropriate marks for each of them. If you give name as input the program
# should output the correponsing marks for that particular student.
# (clue: use a dictionary)

students = {"Ravi":[["physics",47],["Mathematics",45],["Chemistry",45],["Biology",75]],\

             "Sneha":[["physics",95],["Mathematics",34],["Chemistry",45],["Biology",55]],\

"Priya":[["physics",45],["Mathematics",45],["Chemistry",41],["Biology",65]],\

"Kumar":[["physics",45],["Mathematics",83],["Chemistry",72],["Biology",35]],\

"Girish":[["physics",85],["Mathematics",41],["Chemistry",91],["Biology",45]], }

print(students)
