

# Reversing tuple of different data types ##

newtuple = (5,'f',"fantastic",2.345)
print(newtuple)

print(newtuple[-1::-1])
