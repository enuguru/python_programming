
## python program to create a tuple ##
# you can only create a tuple once, cannot change it

# write a program to create a tuple with different data
# types and do the following

# a) delete an element tuple -- not possible
# b) add an element to the tuple  -- not possible
# c) print the element which is 2nd from the beginning
# d) print the element which is 2nd from the last

num = int(input(" Give a number : "))
newtuple = (num,num+2,num+20,num+200)
print(" The elements of the tuple are : ",newtuple)
