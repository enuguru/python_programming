

# write a program to multiply all the data items in a dictionary

newlist = {"One":2,"Two":5,"Three":6}
s = 1

for number in newlist.values():
    s = s * number
print(s)