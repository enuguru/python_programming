
# write a program that uses a set to remove duplicates

## python program to print unique(nonduplicate) values in a dictionary##

nondup = set()

nondup.add(4)
nondup.add(4)
nondup.add(5)
nondup.add(4)
nondup.add(31)
nondup.add(5)
nondup.add(47)

print(nondup)





print(" Non duplicate (unique) values in the dictionary are : ",nondup)
