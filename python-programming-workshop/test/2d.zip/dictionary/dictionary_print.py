
lookup = {"cat": "A domestic animal", "dog": "A grateful domestic animal"}

#The dictionary has no fish key!
print(lookup["cat"])
print(lookup["dog"])
print(lookup)
