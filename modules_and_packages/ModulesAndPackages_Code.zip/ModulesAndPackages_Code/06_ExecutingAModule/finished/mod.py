s = "Computers are useless. They can only give you answers."
a = [100, 200, 300]

def printy(arg):
    print(f'arg = {arg}')

class Classy:
    pass

if (__name__ == '__main__'):
    print(s)
    print(a)
    printy('Good Day Sir!')
    x = Classy()
    print(x)