# Example 01
import mod

# Example 02
import mod

dir()

__name__

mod.__name__

# Example 03
from fact import fact
fact(6)