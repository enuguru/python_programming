print(f'Invoking __init__.py for {__name__}')
import pkg.mod1, pkg.mod2