# Example 01
import pkg

pkg.alist

pkg.mod1

# Example 02
from pkg import mod1

mod1.load_data()

# Example 03
import pkg

pkg.mod1.load_data()
x = pkg.mod2.Location()
x
