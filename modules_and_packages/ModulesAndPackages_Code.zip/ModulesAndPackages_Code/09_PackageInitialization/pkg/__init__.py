print(f'Invoking __init__.py for {__name__}')
alist = ['spam', 'bacon', 'eggs']