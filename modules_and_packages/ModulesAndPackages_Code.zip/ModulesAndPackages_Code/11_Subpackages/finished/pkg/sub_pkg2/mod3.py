def merge_data():
    print('merging data using mod3.merge_data()')

class Message:
    pass

from .. import sub_pkg1
print(sub_pkg1)

from ..sub_pkg1.mod1 import load_data
load_data()
