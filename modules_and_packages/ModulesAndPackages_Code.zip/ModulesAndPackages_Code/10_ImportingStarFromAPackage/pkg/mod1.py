def load_data():
    print('loading data using mod1.load_data()')

class Customer:
    pass