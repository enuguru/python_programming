def send_mail():
    print('sending mail using mod4.send_mail()')

class Winner:
    pass