def clean_data():
    print('cleaning data using mod2.clean_data()')

class Location:
    pass