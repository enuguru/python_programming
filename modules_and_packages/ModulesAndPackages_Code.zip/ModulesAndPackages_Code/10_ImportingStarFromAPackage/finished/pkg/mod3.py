def merge_data():
    print('merging data using mod3.merge_data()')

class Message:
    pass