# Example 01
dir()
from pkg.mod3 import *

dir()

merge_data()
Message

# Example 02
dir()

from pkg import *
dir()

# Example 03
dir()

from pkg import *
dir()

mod1.load_data()
mod4.Winner

# Example 04
dir()

from pkg.mod1 import *
dir()

load_data()
Customer
