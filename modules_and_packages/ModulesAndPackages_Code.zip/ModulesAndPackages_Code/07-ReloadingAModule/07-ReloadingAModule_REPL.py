# Example 01
import mod

import mod
import mod

mod.a
mod.s

# Example 02
import mod

# Example 03
import mod

import mod

import importlib
importlib.reload(mod)