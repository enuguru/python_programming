# Example 01
import mod
mod.a

mod.s

# Example 02
import sys
sys.path

# Example 03
sys.path.append(r'/Users/chris/ModulesAndPackages') # Change this to be the path on your own computer

sys.path
import mod

mod.s

# Example 04
import mod
mod.__file__

import re
re.__file__
