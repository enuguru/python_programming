# Example 01
import mod
mod.a

mod.s

mod.printy('What is up!')

x = mod.Classy()
x
